FORMAT_VERSION: 9

stack trace for /gpfs/fs0/scratch/l/lcl_uotiscscc/lcl_uotiscsccs1041/coding/task3/a.out pid=263150

# Trace

/home/l/lcl_uotiscscc/lcl_uotiscsccs1041/profiler/src/alltoallv/liballtoallv_backtrace.so(_mpi_alltoallv+0xd4) [0x2b1a71e57c10]
/home/l/lcl_uotiscscc/lcl_uotiscsccs1041/profiler/src/alltoallv/liballtoallv_backtrace.so(MPI_Alltoallv+0x7d) [0x2b1a71e58074]
./a.out() [0x409ef2]
/lib64/libc.so.6(__libc_start_main+0xf5) [0x2b1a73069555]
./a.out() [0x409529]

# Context 0

Communicator: 0
Communicator rank: 0
COMM_WORLD rank: 0
Calls: 11, 15, 20, 22-23, 25, 30, 32, 36, 43, 50-52, 54, 58, 60, 66, 68-69, 73, 75, 98-99, 104-105, 109, 111-112, 119, 122, 126, 128-130, 132, 138, 142, 144, 148, 151, 155, 158, 163, 169-170, 172, 179, 200, 202, 204-205, 208, 210, 216-217, 221, 231-233, 236, 240, 243, 248-250, 253-254, 256, 263, 271, 275, 279, 282, 284-285, 287, 293, 298, 303-305, 309, 311, 316, 321, 329, 332, 335, 338, 340-345, 351, 360, 367, 377, 379-380, 387, 389, 394, 400, 402, 410, 412, 417-418, 424, 427, 433, 451-452, 456-457, 462-464, 466, 472, 475, 478-480, 482, 485, 496, 498

