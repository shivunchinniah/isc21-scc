FORMAT_VERSION: 9

stack trace for /gpfs/fs0/scratch/l/lcl_uotiscscc/lcl_uotiscsccs1041/coding/task3/a.out pid=443442

# Trace

/home/l/lcl_uotiscscc/lcl_uotiscsccs1041/profiler/src/alltoallv/liballtoallv_backtrace.so(_mpi_alltoallv+0xd4) [0x2ba3041b8c10]
/home/l/lcl_uotiscscc/lcl_uotiscsccs1041/profiler/src/alltoallv/liballtoallv_backtrace.so(MPI_Alltoallv+0x7d) [0x2ba3041b9074]
./a.out() [0x40d732]
/lib64/libc.so.6(__libc_start_main+0xf5) [0x2ba3053ca555]
./a.out() [0x409529]

# Context 0

Communicator: 0
Communicator rank: 0
COMM_WORLD rank: 0
Calls: 1, 3, 5, 14, 16, 27-28, 33, 39-40, 42, 44, 46, 49, 55, 57, 59, 64, 71, 77, 79-80, 88, 90, 93, 97, 103, 114, 116-117, 124, 133, 150, 160, 164, 176, 182, 201, 206, 213-214, 223, 235, 237, 239, 244, 252, 258, 262, 265, 269, 272, 274, 277, 288-289, 291, 300, 306, 315, 324, 331, 333, 347, 354, 357, 359, 361, 363, 369, 382, 384, 393, 395, 397, 405-406, 408-409, 413, 420, 422-423, 428-430, 434, 436, 440, 449, 460, 467, 469, 474, 476, 484, 495

