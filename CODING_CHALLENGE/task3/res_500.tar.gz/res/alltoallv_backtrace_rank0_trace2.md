FORMAT_VERSION: 9

stack trace for /gpfs/fs0/scratch/l/lcl_uotiscscc/lcl_uotiscsccs1041/coding/task3/a.out pid=443442

# Trace

/home/l/lcl_uotiscscc/lcl_uotiscsccs1041/profiler/src/alltoallv/liballtoallv_backtrace.so(_mpi_alltoallv+0xd4) [0x2ba3041b8c10]
/home/l/lcl_uotiscscc/lcl_uotiscsccs1041/profiler/src/alltoallv/liballtoallv_backtrace.so(MPI_Alltoallv+0x7d) [0x2ba3041b9074]
./a.out() [0x40d595]
/lib64/libc.so.6(__libc_start_main+0xf5) [0x2ba3053ca555]
./a.out() [0x409529]

# Context 0

Communicator: 0
Communicator rank: 0
COMM_WORLD rank: 0
Calls: 2, 9, 34, 67, 89, 92, 96, 102, 106-107, 125, 137, 147, 153-154, 157, 168, 184, 189, 192, 199, 211, 219, 224, 227, 259, 261, 264, 295, 312, 318, 320, 346, 352, 362, 365, 368, 371, 383, 386, 390, 398, 403, 431-432, 439, 445, 450, 458, 489, 492-493

