FORMAT_VERSION: 9

stack trace for /gpfs/fs0/scratch/l/lcl_uotiscscc/lcl_uotiscsccs1041/coding/task3/a.out pid=233680

# Trace

/home/l/lcl_uotiscscc/lcl_uotiscsccs1041/profiler/src/alltoallv/liballtoallv_backtrace.so(_mpi_alltoallv+0xd4) [0x2b58d9cb5c10]
/home/l/lcl_uotiscscc/lcl_uotiscsccs1041/profiler/src/alltoallv/liballtoallv_backtrace.so(MPI_Alltoallv+0x7d) [0x2b58d9cb6074]
./a.out() [0x409e31]
/lib64/libc.so.6(__libc_start_main+0xf5) [0x2b58daec7555]
./a.out() [0x409529]

# Context 0

Communicator: 0
Communicator rank: 0
COMM_WORLD rank: 0
Calls: 0, 4, 10, 12-13, 21, 29, 35, 37-38, 45, 47-48, 53, 61-62, 70, 72, 74, 76, 78, 81-87, 95, 100-101, 115, 118, 120, 131, 135-136, 139-140, 143, 145-146, 152, 156, 161-162, 165-167, 173, 177-178, 181, 183, 185-186, 190-191, 195, 197-198, 207, 209, 212, 218, 220, 229, 242, 247, 251, 255, 267-268, 270, 273, 276, 278, 280-281, 283, 286, 290, 292, 294, 296, 299, 302, 307-308, 313, 319, 325-328, 330, 334, 337, 339, 350, 353, 355-356, 358, 370, 372-373, 375-376, 378, 381, 385, 388, 391-392, 396, 404, 407, 414-416, 419, 421, 425-426, 435, 437-438, 441-444, 447-448, 455, 459, 461, 465, 468, 471, 473, 477, 483, 486-487, 491, 494, 497, 499

