FORMAT_VERSION: 9

stack trace for /gpfs/fs0/scratch/l/lcl_uotiscscc/lcl_uotiscsccs1041/coding/task3/a.out pid=233680

# Trace

/home/l/lcl_uotiscscc/lcl_uotiscsccs1041/profiler/src/alltoallv/liballtoallv_backtrace.so(_mpi_alltoallv+0xd4) [0x2b58d9cb5c10]
/home/l/lcl_uotiscscc/lcl_uotiscsccs1041/profiler/src/alltoallv/liballtoallv_backtrace.so(MPI_Alltoallv+0x7d) [0x2b58d9cb6074]
./a.out() [0x409fc3]
/lib64/libc.so.6(__libc_start_main+0xf5) [0x2b58daec7555]
./a.out() [0x409529]

# Context 0

Communicator: 0
Communicator rank: 0
COMM_WORLD rank: 0
Calls: 6-8, 17-19, 24, 26, 31, 56, 63, 65, 91, 94, 108, 110, 121, 123, 127, 134, 141, 149, 159, 171, 174-175, 180, 187-188, 193-194, 196, 215, 222, 225-226, 228, 230, 234, 241, 245-246, 257, 260, 266, 297, 301, 314, 317, 322-323, 336, 348-349, 366, 374, 399, 401, 411, 446, 453-454, 470, 488, 490

