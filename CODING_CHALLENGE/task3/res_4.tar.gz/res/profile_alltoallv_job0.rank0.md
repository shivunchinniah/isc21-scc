# Summary
COMM_WORLD size: 160
Total number of Alltoallv calls = 500 (limit is 0; -1 means no limit)
# Send/recv counts for Alltoallv operations:

## Data set #0

comm size = 160; Alltoallv calls = 149

### Data sent per rank - Type size: 1

#### Amount of data per rank
Per-rank data is disabled

#### Number of zeros
Per-rank data is disabled
Total: 0/25600 (0.000000%)

#### Data size min/max
DISABLED

#### Small vs. large messages
DISABLED


#### Grouping based on the total amount per ranks

DISABLED

### Data received per rank - Type size: 1

#### Amount of data per rank
Per-rank data is disabled

#### Number of zeros
Per-rank data is disabled
Total: 0/25600 (0.000000%)

#### Data size min/max
DISABLED

#### Small vs. large messages
DISABLED


#### Grouping based on the total amount per ranks

DISABLED


## Data set #1

comm size = 160; Alltoallv calls = 97

### Data sent per rank - Type size: 1

#### Amount of data per rank
Per-rank data is disabled

#### Number of zeros
Per-rank data is disabled
Total: 0/25600 (0.000000%)

#### Data size min/max
DISABLED

#### Small vs. large messages
DISABLED


#### Grouping based on the total amount per ranks

DISABLED

### Data received per rank - Type size: 1

#### Amount of data per rank
Per-rank data is disabled

#### Number of zeros
Per-rank data is disabled
Total: 0/25600 (0.000000%)

#### Data size min/max
DISABLED

#### Small vs. large messages
DISABLED


#### Grouping based on the total amount per ranks

DISABLED


## Data set #2

comm size = 160; Alltoallv calls = 52

### Data sent per rank - Type size: 1

#### Amount of data per rank
Per-rank data is disabled

#### Number of zeros
Per-rank data is disabled
Total: 0/25600 (0.000000%)

#### Data size min/max
DISABLED

#### Small vs. large messages
DISABLED


#### Grouping based on the total amount per ranks

DISABLED

### Data received per rank - Type size: 1

#### Amount of data per rank
Per-rank data is disabled

#### Number of zeros
Per-rank data is disabled
Total: 0/25600 (0.000000%)

#### Data size min/max
DISABLED

#### Small vs. large messages
DISABLED


#### Grouping based on the total amount per ranks

DISABLED


## Data set #3

comm size = 160; Alltoallv calls = 65

### Data sent per rank - Type size: 1

#### Amount of data per rank
Per-rank data is disabled

#### Number of zeros
Per-rank data is disabled
Total: 0/25600 (0.000000%)

#### Data size min/max
DISABLED

#### Small vs. large messages
DISABLED


#### Grouping based on the total amount per ranks

DISABLED

### Data received per rank - Type size: 1

#### Amount of data per rank
Per-rank data is disabled

#### Number of zeros
Per-rank data is disabled
Total: 0/25600 (0.000000%)

#### Data size min/max
DISABLED

#### Small vs. large messages
DISABLED


#### Grouping based on the total amount per ranks

DISABLED


## Data set #4

comm size = 160; Alltoallv calls = 130

### Data sent per rank - Type size: 1

#### Amount of data per rank
Per-rank data is disabled

#### Number of zeros
Per-rank data is disabled
Total: 0/25600 (0.000000%)

#### Data size min/max
DISABLED

#### Small vs. large messages
DISABLED


#### Grouping based on the total amount per ranks

DISABLED

### Data received per rank - Type size: 1

#### Amount of data per rank
Per-rank data is disabled

#### Number of zeros
Per-rank data is disabled
Total: 0/25600 (0.000000%)

#### Data size min/max
DISABLED

#### Small vs. large messages
DISABLED


#### Grouping based on the total amount per ranks

DISABLED


## Data set #5

comm size = 160; Alltoallv calls = 7

### Data sent per rank - Type size: 1

#### Amount of data per rank
Per-rank data is disabled

#### Number of zeros
Per-rank data is disabled
Total: 0/25600 (0.000000%)

#### Data size min/max
DISABLED

#### Small vs. large messages
DISABLED


#### Grouping based on the total amount per ranks

DISABLED

### Data received per rank - Type size: 1

#### Amount of data per rank
Per-rank data is disabled

#### Number of zeros
Per-rank data is disabled
Total: 0/25600 (0.000000%)

#### Data size min/max
DISABLED

#### Small vs. large messages
DISABLED


#### Grouping based on the total amount per ranks

DISABLED

