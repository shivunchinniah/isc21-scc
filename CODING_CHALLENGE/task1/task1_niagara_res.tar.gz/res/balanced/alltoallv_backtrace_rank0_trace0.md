FORMAT_VERSION: 9

stack trace for /gpfs/fs0/scratch/l/lcl_uotiscscc/lcl_uotiscsccs1041/task1/balanced/a.out pid=27402

# Trace

/home/l/lcl_uotiscscc/lcl_uotiscsccs1041/profiler/src/alltoallv/liballtoallv_backtrace.so(_mpi_alltoallv+0xa3) [0x2b17f7fb3a11]
/home/l/lcl_uotiscscc/lcl_uotiscsccs1041/profiler/src/alltoallv/liballtoallv_backtrace.so(MPI_Alltoallv+0x53) [0x2b17f7fb3cd2]
./a.out() [0x408c60]
./a.out() [0x408701]
/lib64/libc.so.6(__libc_start_main+0xf5) [0x2b17f91b3555]
./a.out() [0x4085c9]

# Context 0

Communicator: 0
Communicator rank: 0
COMM_WORLD rank: 0
Calls: 0-999

