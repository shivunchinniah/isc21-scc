FORMAT_VERSION: 9

stack trace for /gpfs/fs0/scratch/l/lcl_uotiscscc/lcl_uotiscsccs1041/task1/unbalanced/a.out pid=446084

# Trace

/home/l/lcl_uotiscscc/lcl_uotiscsccs1041/profiler/src/alltoallv/liballtoallv_backtrace.so(_mpi_alltoallv+0xa3) [0x2b20d65a7a11]
/home/l/lcl_uotiscscc/lcl_uotiscsccs1041/profiler/src/alltoallv/liballtoallv_backtrace.so(MPI_Alltoallv+0x53) [0x2b20d65a7cd2]
./a.out() [0x408a0d]
./a.out() [0x408701]
/lib64/libc.so.6(__libc_start_main+0xf5) [0x2b20d77a7555]
./a.out() [0x4085c9]

# Context 0

Communicator: 0
Communicator rank: 0
COMM_WORLD rank: 0
Calls: 0-999

