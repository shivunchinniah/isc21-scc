# Summary
COMM_WORLD size: 120
Total number of Alltoallv calls = 964 (limit is 0; -1 means no limit)
# Send/recv counts for Alltoallv operations:

## Data set #0

comm size = 120; Alltoallv calls = 121

### Data sent per rank - Type size: 1

#### Amount of data per rank
Per-rank data is disabled

#### Number of zeros
Per-rank data is disabled
Total: 0/14400 (0.000000%)

#### Data size min/max
DISABLED

#### Small vs. large messages
DISABLED


#### Grouping based on the total amount per ranks

DISABLED

### Data received per rank - Type size: 1

#### Amount of data per rank
Per-rank data is disabled

#### Number of zeros
Per-rank data is disabled
Total: 0/14400 (0.000000%)

#### Data size min/max
DISABLED

#### Small vs. large messages
DISABLED


#### Grouping based on the total amount per ranks

DISABLED


## Data set #1

comm size = 120; Alltoallv calls = 121

### Data sent per rank - Type size: 1

#### Amount of data per rank
Per-rank data is disabled

#### Number of zeros
Per-rank data is disabled
Total: 0/14400 (0.000000%)

#### Data size min/max
DISABLED

#### Small vs. large messages
DISABLED


#### Grouping based on the total amount per ranks

DISABLED

### Data received per rank - Type size: 1

#### Amount of data per rank
Per-rank data is disabled

#### Number of zeros
Per-rank data is disabled
Total: 0/14400 (0.000000%)

#### Data size min/max
DISABLED

#### Small vs. large messages
DISABLED


#### Grouping based on the total amount per ranks

DISABLED


## Data set #2

comm size = 120; Alltoallv calls = 361

### Data sent per rank - Type size: 1

#### Amount of data per rank
Per-rank data is disabled

#### Number of zeros
Per-rank data is disabled
Total: 0/14400 (0.000000%)

#### Data size min/max
DISABLED

#### Small vs. large messages
DISABLED


#### Grouping based on the total amount per ranks

DISABLED

### Data received per rank - Type size: 1

#### Amount of data per rank
Per-rank data is disabled

#### Number of zeros
Per-rank data is disabled
Total: 0/14400 (0.000000%)

#### Data size min/max
DISABLED

#### Small vs. large messages
DISABLED


#### Grouping based on the total amount per ranks

DISABLED


## Data set #3

comm size = 120; Alltoallv calls = 361

### Data sent per rank - Type size: 1

#### Amount of data per rank
Per-rank data is disabled

#### Number of zeros
Per-rank data is disabled
Total: 0/14400 (0.000000%)

#### Data size min/max
DISABLED

#### Small vs. large messages
DISABLED


#### Grouping based on the total amount per ranks

DISABLED

### Data received per rank - Type size: 1

#### Amount of data per rank
Per-rank data is disabled

#### Number of zeros
Per-rank data is disabled
Total: 0/14400 (0.000000%)

#### Data size min/max
DISABLED

#### Small vs. large messages
DISABLED


#### Grouping based on the total amount per ranks

DISABLED

