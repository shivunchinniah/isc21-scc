FORMAT_VERSION: 9

ID: 0; world rank: 0
ID: 1; world rank: 0
